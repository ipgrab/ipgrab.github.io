Thanks for downloading Lanc Remastered Edition

For all updates on the latest versions, go to https://lanc-remastered.com

If you have any queries or issues, go to our forum section here - https://lanc-remastered.com/forums

To download Lanc V2, go to https://lanc-remastered.com/download/lanc-v2/

Alternatively, there are different IP Pullers you may use, check out our list here - https://lanc-remastered.com/2019/09/14/top-5-ip-puller-alternatives-for-lanc-remastered/

Peace out!
From LANC REMASTERED Team